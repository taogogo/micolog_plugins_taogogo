# -*- coding: utf-8 -*-
from micolog_plugin import *
from model import *
import re
from google.appengine.api import urlfetch
from xml.dom import minidom
from HTMLParser import HTMLParser
#ȥ��html��ǩ�ĺ�����δʹ��
def strip_tags(html):
     result = []
     parser = HTMLParser()
     parser.handle_data = result.append
     parser.feed(html)
     parser.close()
     return ''.join(result)
class autoblog(Plugin):
	def __init__(self):
		Plugin.__init__(self,__file__)
		self.author="TaoGOGO"
		self.authoruri="http://www.taogogo.info"
		self.uri="http://www.taogogo.info"
		self.description="autoblog Plugin for you to add enty."
		self.name="autoBlog"
		self.version="1.1"
		self.register_urlmap('robot',self.getFeed)

	def get(self,page):
		#query.cityName = self.request.get('cityname')
		if page.param("delid")=='':
			absource=OptionSet.getValue("absource",default="1")
			abrep=OptionSet.getValue("abrep",default="")
			listit = FeedList()
			querys = listit.all()
			cates = Category.all()
			feedDetal=''
			#for detal in querys:
			#	feedDetal=feedDetal+'[name]:'+detal.name+"-[feedURL]:"+detal.feedurl+"<br />"
			return self.render_content("autoblog.html",{'list':querys,'cates':cates,'abrep':abrep,'absource':absource})
		else:
			listit = FeedList()
			querys=listit.all().filter('name =', page.param("delid")).fetch(1)
			for query in querys:
				query.delete()
			#self.redirect('/')
			return "Delete it successfully! <a href='?'>Click here BACK</a>"
		#return self.get(page)
	def post(self,page):
		if page.param("name")!='':
			query = FeedList()
			query.name =page.param("name")
			query.feedurl = page.param("feedurl")
			query.cat = page.param("cat")
			query.abconf = page.param("abconf")
			query.put()
		else:
			OptionSet.setValue("absource",page.param("source"))
			OptionSet.setValue("abrep",page.param("str_rep"))			
		return self.get(page)
		#self.redirect('/')
		#OptionSet.setValue("googleAnalytics_code",code)
		#return self.get(page)
	def getFeed(self,page=None,*arg1,**arg2):
		listit = FeedList()
		querys = listit.all()
		#feedDetal=''
		#print querys[0].feedurl
		#break
		#if leave the master
		absource=OptionSet.getValue("absource",default="1")
		abrep=OptionSet.getValue("abrep",default="girl|woman,")
		abrepArray=abrep.split(",")
		for detal in querys:
			#rss adr
			url=str(detal.feedurl)
			result = urlfetch.fetch(url)
			#page.render2('views/wap.html',{'entrys':entrys,'comments':comments,})
			#print result.content
			if result.status_code == 200:
				file_xml = minidom.parseString(result.content)
				rssNOs=file_xml.getElementsByTagName('rss')
				
				rssver='1.0'
				for rssNO in rssNOs:
					rssver=rssNO.getAttribute('version')
				if rssver=='1.0':
					#items = file_xml.getElementsByTagName('entry')
					artList='entry'
					artTitle='title'
					artLink='link'
					artText='content'
					#artList='entry'
				else:
					artList='item'
					artTitle='title'
					artLink='link'
					artText='description'
					
				items = file_xml.getElementsByTagName(artList)
				
				#print items[0]
				flag=''
				latestId=detal.latest
				ifFirst=0
				for item in items:
					entry=Entry()
					entry.title=item.getElementsByTagName(artTitle)[0].firstChild.data
					if rssver=='1.0':
						flag=item.getElementsByTagName(artLink)[0].getAttribute('href')
					else:
						flag=item.getElementsByTagName(artLink)[0].firstChild.data
					#latestId=detal.latest

					#print flag
					#break
					if latestId=='http://www.taogogo.info/10.html':
						detal.latest=flag
						latestId=flag
						ifFirst=1
						db.put(detal)
					else:
						if flag==latestId:
							break
						else:
							if ifFirst==0:
								detal.latest=flag
								db.put(detal)
								ifFirst=1
						db.put(detal)
					#��ȡ<![CDATA[�ڲ�������
					artContent=item.getElementsByTagName(artText)[0].firstChild.data
					#�滻a��ǩ
					if detal.abconf=='1' or detal.abconf=='3':
						artContent = re.sub("<a([^>]*?)>","",artContent)  
						artContent = re.sub("</a>","",artContent)  
					#�滻img��ǩ
					if detal.abconf=='2' or detal.abconf=='3':
						artContent = re.sub("<img(.*?>)","",artContent)  
					#�滻���з�
					artContent=artContent.replace('\n', "<br />")
					#�滻�趨��
					for repstrs in abrepArray:
						#repstr=['','']
						repstr=repstrs.split("|")
						if len(repstr)>1:
							artContent=artContent.replace(repstr[0],repstr[1])
					if absource=="1":
						artContent=artContent+'<br />VAR:<a href="'.encode('utf8')+flag+'" target="_blank">'.encode('utf8')+entry.title+'</a>'.encode('utf8')
					if detal.cat=='0':
						'''okok i put a byte shit here'''
					else:
						cats = Category.all().filter('name =',detal.cat)
						cat=[]
						cat.append(cats[0].key())
						entry.categorie_keys = cat;
					entry.content=artContent
					entry.save(True)
				#it works
				#print "Successful"
class FeedList(db.Model):
	name = db.StringProperty(multiline=False,default='taogogo')
	feedurl = db.StringProperty(multiline=False,default='http://www.taogogo.info/feed')
	latest = db.StringProperty(multiline=False,default='http://www.taogogo.info/10.html')
	abconf = db.StringProperty(multiline=False,default='0')
	cat = db.StringProperty(multiline=False,default='0')