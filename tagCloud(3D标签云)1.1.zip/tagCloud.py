# -*- coding: utf-8 -*-
from micolog_plugin import *
from model import *
import cgi
import datetime
import wsgiref.handlers

from google.appengine.ext import db
from google.appengine.api import users
from google.appengine.ext import webapp
from urllib import quote
class tagCloud(Plugin):
	#xmlurl='/e/tagcloud.xml'
	#swfurl="/static/tagcloud.swf"
	#swfwidth="300"
	#swfheight="300"
	#baseurl="http://www.taogogo.info"
	def __init__(self):
		Plugin.__init__(self,__file__)
		self.author="TaoGOGO"
		self.authoruri="http://www.taogogo.info"
		self.uri="http://www.taogogo.info"
		self.description="tag cloud Plugin for you to display your tags on blog."
		self.register_filter('tagcloud',self.gettags)
		#self.blocklist=OptionSet.getValue("sys_plugin_blocklist",default="")
		self.name="tagClouds"
		self.version="1.1"
		self.register_urlmap('tagcloud.xml',self.tagxml)
		#self.register_urlmap('twitter',self.getTList)

	def get(self,page):
		swfwidth=OptionSet.getValue("swfwidth",default="300")
		swfheight=OptionSet.getValue("swfheight",default="300")
		#data=OptionSet.getValue("cacheData",default="1")
		xmlurl=OptionSet.getValue("xmlurl",default="/e/tagcloud.xml")
		baseurl=OptionSet.getValue("baseurl",default="http://www.taogogo.info")
		swfurl=OptionSet.getValue("swfurl",default="/static/tagcloud.swf")
		return '''<h3>Setup for your tagcloud</h3>
					<form action="" method="post">
					tagCloud Width:<input name="swfwidth" value="%s" /><br />
					tagCloud Height:<input name="swfheight" value="%s" /><br />
					tagCloud Swf Url:<input name="swfurl" value="%s" /><br />
					tagCloud Link Base:<input name="baseurl" value="%s" /><br />
					tagCloud Xml Url:<input name="xmlurl" value="%s" /><br />
					<br>
					<input type="submit" value="submit">
					</form>
					Powered By <a href="http://www.taogogo.info" target="_blank">TaoGOGO</a>
					'''%(swfwidth,swfheight,swfurl,baseurl,xmlurl)
	
	def post(self,page):
		OptionSet.setValue("swfwidth",page.param("swfwidth"))
		OptionSet.setValue("swfheight",page.param("swfheight"))
		OptionSet.setValue("swfurl",page.param("swfurl"))
		OptionSet.setValue("baseurl",page.param("baseurl"))
		OptionSet.setValue("xmlurl",page.param("xmlurl"))
		return self.get(page)

	def tagxml(self,page=None,*arg1,**arg2):
		baseurl=OptionSet.getValue("baseurl",default="http://www.taogogo.info")
		alltags=Tag.all().order('-tagcount').fetch(60)

		xmls="<tags>".encode('utf8')
		for t in alltags:
			xmls=xmls+'<a href="'.encode('utf8')+baseurl.encode('utf8')+'/tag/'.encode('utf8')+urllib.quote_plus(t.tag.replace('"', "").encode('utf8'))+'" class="tag-link" title="'.encode('utf8')+str(t.tagcount).encode('utf8')+' topics" rel="tag" style="font-size: '.encode('utf8')+str(t.tagcount+9).encode('utf8')+'pt;" >'.encode('utf8')+t.tag.replace('"', "").encode('utf8')+'</a>\n'.encode('utf8')
			
		xmls=xmls+"</tags>".encode('utf8')
		page.response.out.write(xmls)
		#print g_blog.baseurl
		#page.render2('tag',{'tags':xmls})

	def gettags(self,page=None,*arg1,**arg2):
		swfwidth=OptionSet.getValue("swfwidth",default="300")
		swfheight=OptionSet.getValue("swfheight",default="300")
		#data=OptionSet.getValue("cacheData",default="1")
		xmlurl=OptionSet.getValue("xmlurl",default="/e/tagcloud.xml")
		swfurl=OptionSet.getValue("swfurl",default="/static/tagcloud.swf")
		return '''  <object id="tagcloud" width="%s" height="%s" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000">
		<param name="_cx" value="15875" />
			<param name="_cy" value="10583" />
			<param name="FlashVars" VALUE="xmlpath=%s" />
			<param name="Movie" value="tagcloud.swf" />
			<param name="Src" value="%s" />
			<param name="WMode" value="Transparent" />
			<param name="Play" value="0" />
			<param name="Loop" value="-1" />
			<param name="Quality" value="High" />
			<param name="SAlign" value="LT" />
			<param name="Menu" value="-1" />
			<param name="Base" value="" />
			<param name="AllowScriptAccess" value="" />
			<param name="Scale" value="NoScale" />
			<param name="DeviceFont" value="0" />
			<param name="EmbedMovie" value="0" />
			<param name="BGColor" value="FFFFFF" />
			<param name="SWRemote" value="" />
			<param name="MovieData" value="" />
			<param name="SeamlessTabbing" value="1" />
			<param name="Profile" value="0" />
			<param name="ProfileAddress" value="" />
			<param name="ProfilePort" value="0" />
			<param name="AllowNetworking" value="all" />
			<param name="AllowFullScreen" value="false" />
			 <embed  width="%s" height="%s" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" FlashVars=xmlpath=%s src="%s"></embed>
		  </object>
		  <style>#tagsdiv{display:none;}</style>
		  '''%(swfwidth.encode('utf8'),swfheight.encode('utf8'),xmlurl.encode('utf8'),swfurl.encode('utf8'),swfwidth.encode('utf8'),swfheight.encode('utf8'),xmlurl.encode('utf8'),swfurl.encode('utf8'))