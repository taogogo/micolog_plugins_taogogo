# -*- coding: utf-8 -*-
from micolog_plugin import *
from model import *
from xml.dom import minidom
from google.appengine.api import urlfetch
from PyFetion import *
class yawalert(Plugin):
	def __init__(self):
		Plugin.__init__(self,__file__)
		self.author="TaoGOGO"
		self.authoruri="http://www.taogogo.info"
		self.uri="http://www.taogogo.info"
		self.description="天气预报飞信提醒，Yahoo Weather Alert里面挑了几个字母拼成这个名字。"
		self.name="yawalert"
		self.version="1.0"
		self.register_urlmap('yawalert',self.sendFetion)
	def sendFetion(self,page=None,*arg1,**arg2):
		query = weatherSetup().all().fetch(1)
		url=str('http://xml.weather.yahoo.com/forecastrss?u=c&p='+query[0].cityId)
		result = urlfetch.fetch(url)
		file_xml = minidom.parseString(result.content)
		rssNOs=file_xml.getElementsByTagName('yweather:forecast')
		msg="亲爱的"+(query[0].name).encode('utf8')+"，"+(query[0].cityName).encode('utf8')+"天气状况如下:今日"+rssNOs[0].getAttribute('text').encode('utf8')+"["+rssNOs[0].getAttribute('low').encode('utf8')+"~"+rssNOs[0].getAttribute('high').encode('utf8')+"°C]"+"，明天"+rssNOs[1].getAttribute('text').encode('utf8')+"["+rssNOs[1].getAttribute('low').encode('utf8')+"~"+rssNOs[1].getAttribute('high').encode('utf8')+"°C]"
		fetion = PyFetion(query[0].phoneNO,query[0].phonePW,'HTTP')
		fetion.login(FetionOnline)
		fetion.send_sms(msg)
		fetion.logout()
	def get(self,page):
		setit = weatherSetup()
		query = setit.all().fetch(1)
		if query:
			#nowConf= 'Your Name:'+query[0].name+';Your City Id:'+query[0].cityId+';City Name:'+query[0].cityName+';Phone Number:'+query[0].phoneNO+';Phone password:'+query[0].phonePW
			return self.render_content("yawalert.html",{'tao':query[0]})
			
		else:
			setit.put()
			return '''<div>当你看到这个页面的时候，说明插件已经成功执行了~哈哈！~当前设置：默认称呼"taoge",城市名称"zibo",城市代码"CHXX0169",使用时请更改为你的信息。<a href='?'>点击此处进入设置页面</a></div>'''
	def post(self,page):
		query = weatherSetup().all().fetch(1)
		query[0].name = page.param('name')
		query[0].cityId = page.param('cityid')
		query[0].cityName = page.param('cityname')
		query[0].phoneNO = page.param('phoneNO')
		query[0].phonePW = page.param('phonePW')
		db.put(query)
		return "恭喜，修改成功，<a href='?'>点击此处返回</a>"


class weatherSetup(db.Model):
	name = db.StringProperty(multiline=False,default='taoge')
	cityId = db.StringProperty(multiline=False,default='CHXX0169')
	cityName = db.StringProperty(multiline=False,default='zibo')
	phoneNO = db.StringProperty(multiline=False,default='13966666666')
	phonePW = db.StringProperty(multiline=False,default='taogogo')