# -*- coding: utf-8 -*-
from micolog_plugin import *
from model import *
from google.appengine.api import urlfetch
from xml.dom import minidom
import time
class myTList(Plugin):
	def __init__(self):
		Plugin.__init__(self,__file__)
		self.author="TaoGOGO"
		self.authoruri="http://www.taogogo.info"
		self.uri="http://www.taogogo.info"
		self.description="myTList Plugin for you to display your twitter on blog."
		self.register_filter('twitters',self.getTList)
		self.register_urlmap('twirobot',self.getRob)
		#self.blocklist=OptionSet.getValue("sys_plugin_blocklist",default="")
		self.name="myTList"
		self.version="1.2"
		#self.register_urlmap('twitter',self.getTList)

	def get(self,page):
		tcount=OptionSet.getValue("TCount",default="5")
		tname=OptionSet.getValue("TName",default="webfanser")
		#data=OptionSet.getValue("cacheData",default="1")
		cacheTime=OptionSet.getValue("cacheTime",default="1")
		ctime=OptionSet.getValue("cTimeStamp",default="1")
		cdata=OptionSet.getValue("cacheData",default="1")
		return '''<h3>Setup for your My Twitter List</h3>
					<form action="" method="post">
					twitter name:<input name="TName" value="%s" /><br />
					count:<input name="TCount" value="%s" /><br />
					cacheTime:<input name="cacheTime" value="%s" /><br />
					<br>
					<input type="submit" value="submit">
					</form>cache timestamp: %s ;
					Powered By <a href="http://www.taogogo.info" target="_blank">TaoGOGO</a>
					'''%(tname,tcount,cacheTime,ctime)

	def post(self,page):
		tcount=page.param("TCount")
		tname=page.param("TName")
		ctime=page.param("cacheTime")
		OptionSet.setValue("TCount",tcount)
		OptionSet.setValue("TName",tname)
		OptionSet.setValue("cacheTime",ctime)
		return self.get(page)

	def getTList(self,page=None,*arg1,**arg2):
			tcount=OptionSet.getValue("TCount",default="5")
			tname=OptionSet.getValue("TName",default="webfanser")
			ctime=OptionSet.getValue("cacheTime",default='0')
			timestamp=OptionSet.getValue("cTimeStamp",default="0")
			cData=OptionSet.getValue("cacheData")
			#if ctime==''
			#	OptionSet.setValue("cacheTime",ctime)
			#url='http://api.twitter.com/statuses/user_timeline/'+tname+'.xml?count='+tcount
			nowstamp=int(time.time());
			if nowstamp-int(timestamp)<int(ctime):
				return cData
			else:
				#url='http://127.0.0.1/?'+tname+'.xml?count='+tcount
				url='http://api.twitter.com/statuses/user_timeline/'+tname+'.xml?count='+tcount
				result = urlfetch.fetch(url)
				if result.status_code == 200:
					file_xml = minidom.parseString(result.content)					
					statusList = file_xml.getElementsByTagName('status')
					t=''
					for status in statusList:
						t=t+'&Ograve;: '.encode('utf8')+status.getElementsByTagName("text")[0].firstChild.data.encode('utf8')+'<br />'.encode('utf8')
					data=t+'<a href="http://www.twitter.com/'.encode('utf8')+tname.encode('utf8')+'" target="_blank">Follow Me</a>'.encode('utf8')
					OptionSet.setValue("cacheData",data)
					OptionSet.setValue("cTimeStamp",nowstamp)
					return data
	def getRob(self,page=None,*arg1,**arg2):
			tcount=OptionSet.getValue("TCount",default="5")
			tname=OptionSet.getValue("TName",default="webfanser")
			ctime=OptionSet.getValue("cacheTime",default='0')
			timestamp=OptionSet.getValue("cTimeStamp",default="0")
			cData=OptionSet.getValue("cacheData")
			#if ctime==''
			#	OptionSet.setValue("cacheTime",ctime)
			#url='http://api.twitter.com/statuses/user_timeline/'+tname+'.xml?count='+tcount
			nowstamp=int(time.time());
			url='http://api.twitter.com/statuses/user_timeline/'+tname+'.xml?count='+tcount
			result = urlfetch.fetch(url)
			if result.status_code == 200:
				file_xml = minidom.parseString(result.content)					
				statusList = file_xml.getElementsByTagName('status')
				t=''
				for status in statusList:
					t=t+'&Ograve;: '.encode('utf8')+status.getElementsByTagName("text")[0].firstChild.data.encode('utf8')+'<br />'.encode('utf8')
				data=t+'<a href="http://www.twitter.com/'.encode('utf8')+tname.encode('utf8')+'" target="_blank">Follow Me</a>'.encode('utf8')
				OptionSet.setValue("cacheData",data)
				OptionSet.setValue("cTimeStamp",nowstamp)
	