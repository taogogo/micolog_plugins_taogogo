from micolog_plugin import *
import logging
from model import *
from google.appengine.api import users
class wap(Plugin):
	def __init__(self):
		Plugin.__init__(self,__file__)
		self.author="TaoGOGO"
		self.authoruri="http://www.taogogo.info"
		self.uri="http://www.taogogo.info"
		self.description="Wap plugin for micolog."
		self.name="WAP Micolog"
		self.version="1.1"
		#Set The Url
		self.register_urlmap('wap',self.wap)
		self.register_urlmap('wap/page',self.page)
	#wap page
	def wap(self,page=None,*arg1,**arg2):
		wapEntry = Entry.all().filter("published =", True).filter('entrytype =','post').order('-date')
		wapComment = Comment.all().order('-date')
		comments = wapComment.fetch(5)
		entrys = wapEntry.fetch(8)
		template_values = {
			'entrys': entrys,
			'comments': comments,
		}
		
		#tempstr='''This is a tpl'''
		page.render2('views/wap.html',{'entrys':entrys,'comments':comments,})
		#self.render_content("wap.html")
	#it works
	def page(self,page,*arg1,**arg2):
		id=int(page.param("id"))
		#print id
		entrys = Entry.all().filter("published =", True).filter('entrytype =','post').filter('post_id =',id).fetch(1)
		entry=entrys[0]
		comments=Comment.all().filter("entry =",entry)
		#print comments
		page.render2('views/wapc.html',{'entrys':entry,'id':id,'comments':comments,})
	#it works
	def get(self,page):
		#self.render_content("wap.html")
		return '''
		<h3>It works well^_^</h3>
		<p>Congratulation! Your \"WAP Micolog\" plugin is working now!<br />The URL of the wap site is 
		<a href="/e/wap" target="_blank">http://www.example.com/e/wap</a><br />
		<b>Author:</b><a href="http://www.taogogo.info" target="_blank">TaoGOGO</a><br/></p>
		
		'''
